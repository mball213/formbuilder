import { describe, it, expect } from 'vitest'
describe('smoke',()=>{it('adds',()=>{expect(1+1).toBe(2)})})
